1. Create an S3 bucket (e.g., `my-image-uploader-baba`)
2. Create Lambda Function in Python
3. Write the `lambda_function.py` code
4. Add trigger: API Gateway (HTTP API or REST)
5. Assign IAM Role to Lambda with `AmazonS3FullAccess` policy
6. Test using Postman or API endpoint

✅ Done!
